/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'bg', {
	alt: 'Алтернативен текст',
	btnUpload: 'Изпрати я на сървъра',
	captioned: 'Надписано изображение',
	captionPlaceholder: 'Надпис',
	infoTab: 'Детайли за изображението',
	lockRatio: 'Заключване на съотношението',
	menu: 'Настройки на изображението',
	pathName: 'изображение',
	pathNameCaption: 'надпис',
	resetSize: 'Нулиране на размер',
	resizer: 'Кликни и влачи, за да преоразмериш',
	title: 'Настройки на изображението',
	uploadTab: 'Качване',
	urlMissing: 'URL адреса на изображението липсва.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
