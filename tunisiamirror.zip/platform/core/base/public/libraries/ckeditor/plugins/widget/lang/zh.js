/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'widget', 'zh', {
	'move': '拖曳以移動',
	'label': '%1 小工具'
} );
