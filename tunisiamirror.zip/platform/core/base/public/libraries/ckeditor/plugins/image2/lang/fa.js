/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'fa', {
	alt: 'متن جایگزین',
	btnUpload: 'به سرور بفرست',
	captioned: 'تصویر زیرنویس شده',
	captionPlaceholder: 'عنوان',
	infoTab: 'اطلاعات تصویر',
	lockRatio: 'قفل کردن نسبت',
	menu: 'ویژگی​های تصویر',
	pathName: 'تصویر',
	pathNameCaption: 'عنوان',
	resetSize: 'بازنشانی اندازه',
	resizer: 'کلیک و کشیدن برای تغییر اندازه',
	title: 'ویژگی​های تصویر',
	uploadTab: 'بالاگذاری',
	urlMissing: 'آدرس URL اصلی تصویر یافت نشد.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
